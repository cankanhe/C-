#pragma once
/////////////////////////////////////////////////////////////////////
// Client.h - Prototype for Test Harness child Tester              //
// ver 1.0                                                         //
// Cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  This package defines one class, Cleint:
*  - use the comm and message establish commnucation channel and 
*    using thread send and receive message and construct testRequest
*
*  Required Files:
*  ---------------
*  Client.h, Client.cpp
*  comm.h, comm.cpp
*  ISingletonLogger.h, SingletonLogger.h
*  TestRequest.h, TestRequest.cpp
*  Properties.h, Properties.cpp
*  FileUtilities.h, FileUtilities.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9 Nov 2018
*  - first release
*
*/
#ifndef WIN32_LEAN_AND_MEAN  // prevents duplicate includes of core parts of windows.h in winsock2.h
#define WIN32_LEAN_AND_MEAN
#endif
#include "../TestRequest/TestRequest.h"
#include "../CppCommWithFileXfer/MsgPassingComm/Comm.h"
#include "../Utilities/FileUtilities/FileUtilities.h"
#include <iostream>
#include <functional>
#include <windows.h>
///////////////////////////////////////////////////////////////////
  // Client class
  // - construct TestRequest.
  //   Each TestRequest provides names of Dlls to load and test
  // - put TestRequest into the message.
  // - establish comm through EndPoint
  //   using Thread to build receive endpoint
  // - send Message through comm
  // - Each test will receive a message from the tester.
namespace Testing
{
	using namespace MsgPassingCommunication;
	Property<Request> request;
	class Client 
	{
	public:
		Client(EndPoint from, EndPoint to,const std::string name);
		~Client();
		void ClientName(const std::string name);
		void ClientTime();
		void ClientAuthor(const std::string name);
		void ClinetDLL(const std::string dll);
		std::string getRequest(int &i);
		void start();
		void wait();
		void sendMsg(const std::string&name);
		void getMsgs();
		void join();
	private:
		TestRequest tr1;
		EndPoint from_;
		EndPoint to_;
		Comm comm_;
		std::thread recv;
	};
}
