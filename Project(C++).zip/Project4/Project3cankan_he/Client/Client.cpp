/////////////////////////////////////////////////////////////////////
// Client.cpp - creates TestRequest and stores in requestPath      //
// ver 1.0                                                         //
// cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  Client creates test request and stores in requestPath.
*  - This simulates what a Project #4 client does, e.g., creates
*    TestRequests and sends to TestHarness via a Comm channel.
*
*  Required Files:
*  ---------------
*  Client.cpp
*  TestRequest.h, TestRequest.cpp
*  DateTime.h, DateTime.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 23 Oct 2018
*  - first release
*/


#include "Client.h"
namespace Testing
{
	//----< constructor >------------------
	Client::Client(EndPoint from, EndPoint to, const std::string name) : comm_(from_, name), from_(from), to_(to) {}
	//----< destructor >------------------
	Client::~Client()
	{
		std::cout << "\n" << "delete client";
	}
	//----< set request name >------------------
	void Client::ClientName(const std::string name)
	{
		tr1.name(name);
	}

	//----< set request time >------------------

	void Client::ClientTime()
	{
		tr1.date(DateTime().now());
	}
	//----< set request author >------------------
	void Client::ClientAuthor(const std::string name)
	{
		tr1.author(name);
	}
	//----< set request dll >------------------
	void Client::ClinetDLL(const std::string dll)
	{
		tr1.request.valueRef().push_back(dll);
	}
	//----< get request >------------------
	std::string Client::getRequest(int &i)
	{
		tr1.tostring();
		return tr1.getstring(i); //this method reconstruct one testRequest into string vector and the size depend on the how many dll file
	}
	//----< set comm start >------------------
	void Client::start()
	{
		comm_.start();
		std::string sendPath = comm_.setSendFilePath("C:\\Users\\OOD\\Desktop\\Project#4\\Project3cankan_he\\Debug");
		std::cout << "\n  sending files from \"" << sendPath << "\"";
	}
	//----< set thread to receive message >------------------
	void Client::wait()
	{
		std::function<void()> tproc = [&]() { getMsgs(); };
		recv = std::thread(tproc);
	}
	//----< set send message >------------------
	void Client::sendMsg(const std::string&name)
	{
		MsgPassingCommunication::Message fileMsg;
		int i = 0;
		for (auto dll : tr1.request())
		{
			fileMsg.to(to_);
			fileMsg.from(from_);
			fileMsg.name(name);
			fileMsg.command("testRequest");       // Identify the Message Categroy TestRequest Message or Ready Message
			fileMsg.file(dll);
			fileMsg.testRequest(getRequest(i));   // add the TestRequest string to the testRequest atrribute 
			std::cout << "\n  " + comm_.name() + " posting: " + fileMsg.name() + "\n ";
			comm_.postMessage(fileMsg);
			i++;
		}
	}
	//----< set Receive Message >------------------
	void Client::getMsgs()
	{
		MsgPassingCommunication::Message msg;
		while (true)
		{
			msg = comm_.getMessage();
			std::cout << "\n  client recvd  message \"" << msg.Result() << "\"";     //child Tester put TestRequest and  
			if (msg.command() == "stop")                                           //test result into the message name attribute_
				break;
		}
	}
	//----< set join >------------------
	void Client::join()
	{
		recv.join();
	}
}

using namespace Testing;

int main()
{
	Utilities::Title("Demonstrating Client");
	::SetConsoleTitle(L"Client");
	EndPoint client("localhost", 8081);
	EndPoint host("localhost", 8080);
	Client user(client, host, "Client");
	user.ClientName("DemostrationProject3");
	user.ClientAuthor("cankan");
	user.ClientTime();
	user.ClinetDLL("DemoRequest1.dll");
	user.ClinetDLL("DemoRequest2.dll");
	user.ClinetDLL("DemoRequest3.dll");
	user.ClinetDLL("DemoRequest4.dll");
	user.ClinetDLL("DemoRequest5.dll");
	user.ClinetDLL("DemoRequest6.dll");
	user.start();
	user.wait();
	user.sendMsg("DemoRequest");
	user.join();
	return 0;
}

