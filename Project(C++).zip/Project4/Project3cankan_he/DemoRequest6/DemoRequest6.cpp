///////////////////////////////////////////////////////////////////////////
// Project3Demo1.cpp :  test class for CodeUtilities pkg                  //
// ver 1.1                                                                //
//                                                                        //
// Application : OOD F18 Project 3 Demostrate porject requirement         //
// Platform    : VS17 Community - Windows 10 Professional x64             //
// Author      : Cankan He, EECS Department, Syracuse University          //
//               che100@syr.edu                                           //
////////////////////////////////////////////////////////////////////////////
/*
*  Package description:
* ======================
*  This is a 'Mutiple test' test driver DLL package. It follows the same
*  protocol defined in ITest.h package. For DllLoader, it doesn't care
*  if the TestDriver contains one or many Test Classes as it will attempt
*  to get the collection of ITest*.
*
*  Required files:
* =================
*  ProjectDemo.cpp
*  ITest.h
*  FileUtilities.h
*  FileSystem.h
*  Maintainence History:
* =======================
*  ver 1.0 : 11 Oct 2018
*  - added Hosted ILoger interface
*  - Tests use host functionality via passed pointer to
*    IHostedResource interface
*  - first release
*/

#define IN_DLL
#define ARG_SIZE 256  // for the manufactured cmd args

#include "ITests.h"
#include "../Utilities/CodeUtilities/CodeUtilities.h"
#include "../Utilities/DateTime/DateTime.h"
#include "../Utilities/FileUtilities/FileUtilities.h"

#include <iostream>
#include <string>
#include <string.h>

using namespace Utilities;
using namespace std;
using namespace std;
using Path = std::string;
using Message = std::string;
using Line = size_t;
using File = std::string;
using Files = std::vector<File>;
using Pattern = std::string;
using Patterns = std::vector<Pattern>;


// Concrete Test class that implements ITest.
// It performs tests on ProcessCmdArgs and Convereter classes in a single test class.

class Req6a : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< requirment >------------------
DLL_DECL bool Req6a::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #6a - Client process that sends HTTP style TestRequest messages ";
	pRes_->write(msg);
	msg = "\n========================================================================";
	Path fileSpec = "../Client/Client.cpp";
	pRes_->write("\n user input string argument to construct testRequest:'name'time'author'dll'dll'....");
	bool t1 = Utilities::showFileLines(fileSpec, 36, 57);
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	pRes_->write("\n getRequest method extract bunch of request from the TestRequest see the comment:");
	bool t2 = Utilities::showFileLines(fileSpec, 58, 63);
	pRes_->write(msg);
	pRes_->write("sends HTTP style TestRequest messages");
	bool t3 = Utilities::showFileLines(fileSpec, 77, 95);
	return (t1 == true && t2 == true && t3 == true);
}
//----< name >------------------
DLL_DECL std::string Req6a::name()
{
	return string("Demo Request6a");
}
//----< author >------------------
DLL_DECL std::string Req6a::author()
{
	return string("cankan he");
}
//----< Requirment >------------------
class Req6b : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< Requirment>------------------
DLL_DECL bool Req6b::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #6b - receives and displays test results in the form of HTTP style messages";
	pRes_->write(msg);
	msg = "\n========================================================================";
	pRes_->write(msg);
	pRes_->write("\n demonstrate Child Tester pass Logger ponit to Test Dll and make Tester can get entrie Test report");
    Path fileSpec = "../Client/Client.cpp";
	bool t1 = Utilities::showFileLines(fileSpec, 96, 107);
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	pRes_->write("\n user just need input dll into the testRequest and client will rebuild it and generate multiple TestRequest");
	bool t2 = Utilities::showFileLines(fileSpec, 119, 138);
	return (t1 == true && t2 == true);
}
//----< name >------------------
DLL_DECL std::string Req6b::name()
{
	return string("Demo Request6b");
}
//----< author >------------------
DLL_DECL std::string Req6b::author()
{
	return string("cankan he");
}
//////////////////////////////////////////////////////////////////////////////
// test collection 

class TestCollection : public ITests {
	DLL_DECL std::vector<ITest*> tests();
};
//----< push back ITests vector >------------------
DLL_DECL std::vector<ITest*> TestCollection::tests()
{
	std::vector<ITest*> tests_vec;
	tests_vec.push_back(new Req6a);
	tests_vec.push_back(new Req6b);

	return tests_vec;
}

//////////////////////////////////////////////////////////////////////////////
// this section is where each Test Driver DLL completely differs from other
// test drivers. Although the same name can be used in all TestDrivers, the 
// actual instance of TestCollection is different in the way it returns 
// different collection of ITest*.

DLL_DECL ITests* get_ITests()
{
	return new TestCollection;
}

