/////////////////////////////////////////////////////////////////////
// Tester.cpp - Prototype for Test Harness child Tester            //
// ver 1.0                                                         //
// cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////

#ifndef WIN32_LEAN_AND_MEAN  // prevents duplicate includes of core parts of windows.h in winsock2.h
#define WIN32_LEAN_AND_MEAN
#endif
#include "Tester.h"
#include "../Dll_Loader_With_Hosted_Resource/ITests.h"
#include "../Utilities/TestUtilities/TestUtilities.h"
#include "../Utilities/FileSystem/FileSystem.h"
#include "../Utilities/FileUtilities/FileUtilities.h"
#include "../Utilities/StringUtilities/StringUtilities.h"
#include "../CppCommWithFileXfer/Message/Message.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <memory>
#include <windows.h>
#include <thread>
#include <functional>


namespace Testing
{
	//----< initialize paths and logger >------------------------------
	Tester::Tester(EndPoint &from, EndPoint &to, const std::string &name) :from_(from), to_(to), comm_(from_, name)
	{
		libPath("../SaveFile");
		pLog(Utilities::Logger<0, Utilities::Lock>::getInstance());
		pLog()->setTerminator("");
	}

	//----< deallocate logger >----------------------------------------

	Tester::~Tester()
	{
		delete pLog();
	}
	//----< load Test Requests >-----------------------------------------
	/*
	* - In Project #4 serialized TestRequests, sent by client, will be
	*   extracted from Comm channel.
	*/
	void Tester::loadTestRequests()
	{
		if (TR != "")
		{
			tr1 = TestRequest::fromString(TR);
			requests.valueRef().push_back(tr1);
			pLog()->write("\n  loaded TestRequest \"" + tr1.name() + "\"");
			pLog()->write("\n  " + tr1.toString() + "\n");
		}

	}
	//----< load libraries >---------------------------------------------
	/*
	* - Loads all libraries specified in a TestRequest from libPath.
	* - Uses DllLoader member, dllLoader_, to load dlls and extract
	*   their tests.
	*/
	void Tester::loadLibraries()
	{
		std::string path = FileSystem::Path::getFullFileSpec(libPath());
		pLog()->write("\n  loading from \"" + path + "\"");

		std::vector<std::string> files;
		for (Dll dll : tr1.request.valueRef())
		{
			files.push_back(dll);
		}

		for (auto file : files)
		{
			pLog()->write("\n    " + file);
			std::string fileSpec = path + "\\" + file;
			dllLoader_.loadAndExtract(fileSpec);
		}
		pLog()->write("\n");
	}
	//----< executes tests >--------------------------
	/*
	* - Executes tests held by DllLoader instance,
	*   using TestUtilities infrastructure.
	*/
	bool Tester::doTests()
	{
		using sPtr = std::shared_ptr<ITest>;
		Utilities::TestExecutive te;
		for (ITest* test : dllLoader_.tests()) {
			// Host passes logger resource pointer to test
			// - test will use logger via this pointer
			test->acceptHostedResource(pLog.valueRef());
			sPtr pTest(test);
			te.registerTest(pTest, pTest->name());
		}
		bool result = te.doTests();
		return result;
	}
	//----< receive the message from the Host>----------------------------------------
	void Tester::getMsgs()
	{
		MsgPassingCommunication::Message msg;
		while (true)
		{
			msg = comm_.getMessage();
			Reply.enQ(msg);    //put Message to Reply quence just want get client port, IP address and TestRequest information
			std::cout << "\n  Tester recvd  message \"" << msg.name() << "\"";
			if (msg.command() == "stop")
				break;
			else if (msg.command() == "testRequest")
			{
				TR = msg.testRequest();       //extra the TestRequest
				loadTestRequests();           // load TestRequest
				bool result = executeTest();  //  do test
				Re.enQ(result);               // return result into the  bool type Queue
			}
		}
	}
	//----< send the ready message to the Host and send Result to client >----------------------------------------
	void Tester::sndMsgs()
	{
		while (true)
		{
			MsgPassingCommunication::Message msg;
			MsgPassingCommunication::Message ready;
			ready.command("ready");
			ready.to(to_);
			ready.from(from_);
			ready.name("child");
			comm_.postMessage(ready);     //send ready message to host
			msg = Reply.deQ();            // it will block untill receive the TestRequest 
			if (msg.command() == "stop")  //check it's a TestRequest or not 
			{
				msg.to(msg.from());
				msg.from(from_);
				comm_.postMessage(msg);
				break;
			}
			else
			{
				MsgPassingCommunication::Message reply;
				reply.to(msg.from());
				reply.from(from_);
				reply.command("testResult");
				bool result = Re.deQ();    //it will block untill finish the test and get result from bool queue.
				if (result)
				{
					reply.Result(TR + "- pass the test");   // TR is string of Tester private member contain the TestRequest.
				}
				else
				{
					reply.Result(TR + " - fail the test");
				}
				comm_.postMessage(reply);  // send reply message to client
			}
		}
	}
	//----< do the Test>----------------------------------------
	bool Tester::executeTest()
	{
		bool result = false;
		loadLibraries();
		result = doTests();
		clear();
		return result;
	}
	//----< start comm >----------------------------------------
	void Tester::start()
	{
		comm_.start();
	}
	//----< set Thread to receive the message>----------------------------------------
	void Tester::wait()
	{
		std::function<void()> tproc = [&]() { getMsgs(); };
		recv = std::thread(tproc);
	}
	//----< detach the receive Thread>----------------------------------------
	void Tester::detach()
	{
		recv.detach();
	}
}

using namespace Testing;

int main(int argc, char* argv[])
{
	if (argc != 3)
	{
		std::cout << "\n  Please enter right argment \n";
		return 1;
	}
	std::string localhost = argv[1];
	std::string port = argv[2];
	int number = stoi(port);
	Utilities::Title("child process Testing TestRequest");
	::SetConsoleTitle(L"Tester");
	EndPoint Host(localhost, 8080);
	EndPoint Test(localhost, number);
	TestRequest tr;
	Tester tester(Test, Host, "Tester");
	tester.start();
	tester.wait();
	tester.sndMsgs();
	tester.detach();
	Utilities::putline(2);
	return 0;
}
