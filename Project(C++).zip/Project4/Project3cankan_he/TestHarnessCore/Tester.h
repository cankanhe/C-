#pragma once
/////////////////////////////////////////////////////////////////////
// Tester.h - Prototype for Test Harness child Tester              //
// ver 1.0                                                         //
// cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  This package defines one class, Tester:
*  - uses DllLoader to load libraries and extract tests.
*  - provides pointer to its member logger to each test, then
*    executes it, using the infrastructure from TestUtilities.
*  - receive messge to test
*
*  Required Files:
*  ---------------
*  Tester.h, Tester.cpp
*  Comm,h,   Comm.cpp
*  TestRequest.h, TestRequest.cpp
*  DllLoader.h, DllLoader.cpp
*  ISingletonLogger.h, SingletonLogger.h
*  ITest.h, TestUtilities.h
*  Properties.h, Properties.cpp
*  FileUtilities.h, FileUtilities.cpp
*  FileSystem.h, FileSystem.cpp
*  StringUtilities.h
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9 Nov 2018
*  - first release
*
*/
#include "../TestRequest/TestRequest.h"
#include "../Dll_Loader_With_Hosted_Resource/DllLoader/DllLoader.h"
#include "../Utilities/SingletonLogger/ISingletonLogger.h"
#include "../Utilities/SingletonLogger/SingletonLogger.h"
#include "../Utilities/Properties/Properties.h"
#include <vector>
#include <string>
#include "../CppCommWithFileXfer/MsgPassingComm/Comm.h"

namespace Testing
{
  using namespace Utilities;
  using namespace MsgPassingCommunication;
  ///////////////////////////////////////////////////////////////////
  // Tester class
  // - receive message and get the requestPath
  // - Loads TestRequests from requestPath.
  //   Each TestRequest provides names of Dlls to load and test
  // - Loads Test Dynamic Link Libraries (Dlls) from libPath.
  // - Executes tests defined in each Dll.
  // - Each tests logs ouputs using Tester class's logger
  // - return the test reslut message to client

  using Requests = std::vector<TestRequest>;

  class Tester
  {
  public:
    Tester(EndPoint &from,EndPoint &to,const std::string &name);
    ~Tester();
    Property<Requests> requests;
    Property<std::string> libPath;
    Property<ILog*> pLog;
    void loadTestRequests();
    void loadLibraries();
    bool doTests();
    void setLibraryPath(std::string& path)
    {
      libPath(path);
    }
    void clear()
    {
      dllLoader_.clear();
    }
	void start();
	void wait();
	void detach();
	void getMsgs();
	void sndMsgs();
	bool executeTest();
  private:
    DllLoader dllLoader_;
	TestRequest tr1;
	std::string TR="";
	EndPoint from_;
	EndPoint to_;
	Comm comm_;
	std::thread recv;
	BlockingQueue<bool> Re;
	BlockingQueue<MsgPassingCommunication::Message> Reply;
  };
}
