////////////////////////////////////////////////////////////////////////////
// SingleTestUtil.cpp : single test class for CodeUtilities pkg           //
// ver 1.1                                                                //
//                                                                        //
// Application : OOD F18 Project 2 Help                                   //
// Platform    : VS17 Community - Windows 10 Professional x64             //
// Modified    : Jim Fawcett, CSE687 - OOD, Fall 2018
// Author      : Ammar Salman, EECS Department, Syracuse University       //
//               313/788-4694, hoplite.90@hotmail.com                     //
////////////////////////////////////////////////////////////////////////////
/*
*  Package description:
* ======================
*  This is a 'single test' test driver DLL package. It follows the same
*  protocol defined in ITest.h package. For DllLoader, it doesn't care
*  if the TestDriver contains one or many Test Classes as it will attempt
*  to get the collection of ITest*.
*
*  Required files:
* =================
*  SingleTestUtil.cpp
*  ITest.h
*  CodeUtilities.h
*
*  Maintainence History:
* =======================
*  ver 1.1 : 07 Oct 2018
*  - added Hosted Resource infrastructure
*  - Tests use host functionality via passed pointer to
*    IHostedResource interface
*  ver 1.0 - first release
*/

#define IN_DLL
#define ARG_SIZE 256  // for the manufactured cmd args


#include "../Dll_Loader_With_Hosted_Resource/ITests.h"
#include "../Dll_Loader_With_Hosted_Resource/CodeUtilities/CodeUtilities.h"
#include <iostream>
#include <string.h>
#include "../Utilities/FileUtilities/FileUtilities.h"
#include "../Utilities/FileSystem/FileSystem.h"
using namespace Utilities;
using namespace std;
using Path = std::string;
using Message = std::string;
using Line = size_t;
using File = std::string;
using Files = std::vector<File>;
using Pattern = std::string;
using Patterns = std::vector<Pattern>;
// Concrete Test class that implements ITest.
// It performs tests on ProcessCmdArgs and Convereter classes in a single test class.

class Req1 : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req1::test()
{
	
	Message msg = "\n  Req #1 - Use C++";
	plog_->write(msg);
	msg = "\n ------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n Demonstrate by viewing files in project directory");
	Path path = "../Executive";
	Patterns pats = { "*.h", "*.cpp" };

	return Utilities::showDirContents(path, "", pats);
}

DLL_DECL std::string Req1::name()
{
	return string("requirement 1");
}

DLL_DECL std::string Req1::author()
{
	return string("cankan he");
}

class Req2a : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req2a::test()
{
	Message msg = "\n  Req #2a - use std::streams";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate by viewing code - see line 93");
	Path fileSpec = "../Logger/Logger.h";
	return Utilities::showFileLines(fileSpec, 70, 100);
}

DLL_DECL std::string Req2a::name()
{
	return string("requirement 2a");
}

DLL_DECL std::string Req2a::author()
{
	return string("cankan he");
}

class Req2b : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req2b::test()
{
	Message msg = "\n  Req #2b - use new and delete";
	plog_->write(msg);
	msg = "\n ------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n Demonstrate by viewing project source code");
	plog_->write("\n Use of new demonstrates");
	Path fileSpec = "../Project2Demo/demostrate.cpp";
	return Utilities::showFileLines(fileSpec, 180, 185);
}

DLL_DECL std::string Req2b::name()
{
	return string("requirement 2b");
}

DLL_DECL std::string Req2b::author()
{
	return string("cankan he");
}

class Req3a : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req3a::test()
{
	Message msg = "\n  Req #3a - provide an Executive package";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate by viewing code - see line 93");
	Path fileSpec = "../Executive/Executive.h";
	return Utilities::showFileLines(fileSpec, 1, 20);
}

DLL_DECL std::string Req3a::name()
{
	return string("requirement 3a");
}

DLL_DECL std::string Req3a::author()
{
	return string("cankan he");
}

class Req3b : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req3b::test()
{
	Message msg = "\n  Req #3b -  loads all the test libraries from a specified directory";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate by viewing code - see line 93");
	Path fileSpec = "../Executive/Executive.h";
	return Utilities::showFileLines(fileSpec, 124, 131);
}

DLL_DECL std::string Req3b::name()
{
	return string("requirement 3b");
}

DLL_DECL std::string Req3b::author()
{
	return string("cankan he");
}

class Req3c : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req3c::test()
{
	Message msg = "\n  Req #3c - executes the TestRequest from each library after loading.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate by viewing code - see line 93");
	Path fileSpec = "../Executive/Executive.h";
	return Utilities::showFileLines(fileSpec, 149, 166);
}

DLL_DECL std::string Req3c::name()
{
	return string("requirement 3c");
}

DLL_DECL std::string Req3c::author()
{
	return string("cankan he");
}

class Req4 : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req4::test()
{
	Message msg = "\n  Req #4 - Loader, Executor, and Logger packages.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate Loader package");
	Path path = "../Loader";
	Patterns pats = { "*.h", "*.cpp" };
	bool t1 = Utilities::showDirContents(path, "", pats);
	plog_->write(msg);
	plog_->write("\n demonstrate Executor package");
	path = "../Executive";
	bool t2 = Utilities::showDirContents(path, "", pats);
	plog_->write(msg);
	plog_->write("\n demonstrate Logger package");
	path = "../Logger";
	bool t3 = Utilities::showDirContents(path, "", pats);
	return(t1 == true && t2 == true && t3 == true);
}

DLL_DECL std::string Req4::name()
{
	return string("requirement 4");
}

DLL_DECL std::string Req4::author()
{
	return string("cankan he");
}

class Req5a : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req5a::test()
{
	Message msg = "\n  Req #5a -   Loading a path specified by the Executive.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate the path when instance a Executive class object  - see line 93");
	Path fileSpec = "../Executive/Executive.cpp";
	bool t1= Utilities::showFileLines(fileSpec, 72, 94);
	plog_->write(msg);
	plog_->write("\n demonstrate the Executive specifiled path   - see line 93");
	fileSpec = "../TestHarnessCore/TestHarnessCore.cpp";
	bool t2 = Utilities::showFileLines(fileSpec, 0, 20);
	return (t1 == true && t2 == true);
}

DLL_DECL std::string Req5a::name()
{
	return string("requirement 5a");
}

DLL_DECL std::string Req5a::author()
{
	return string("cankan he");
}

class Req5b : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req5b::test()
{
	Message msg = "\n  Req #5a - Loader package  support finding and loading all the test libraries.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate finding  dll which path specified by the Executive- see line 93");
	Path fileSpec = "../Loader/Loader.cpp";
	bool t1 = Utilities::showFileLines(fileSpec, 33, 56);
	plog_->write(msg);
	plog_->write("\n demonstrate Load dll which path specified by the Executive   - see line 93");
	fileSpec = "../Loader/Loader.cpp";
	bool t2 = Utilities::showFileLines(fileSpec, 30, 57);
	return (t1 == true && t2 == true);
}

DLL_DECL std::string Req5b::name()
{
	return string("requirement 5b");
}

DLL_DECL std::string Req5b::author()
{
	return string("cankan he");
}

class Req7a : public ITest{

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req7a::test()
{
	Message msg = "\n  Req #7a -  Logger support sending messages constructed by each test driver to standard C++ streams.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate default addstream to cout and also can add to other streams- see line 93");
	Path fileSpec = "../Logger/Logger.h";
	bool t1 = Utilities::showFileLines(fileSpec, 71, 97);
	plog_->write(msg);
	plog_->write("\n demonstrate That could be the process console, a file, or a std::ostringstream through the addstream method  - see line 93");
	fileSpec = "../Logger/Logger.h";
	bool t2 = Utilities::showFileLines(fileSpec, 112, 134);
	return (t1 == true && t2 == true);
}

DLL_DECL std::string Req7a::name()
{
	return string("requirement 7a");
}

DLL_DECL std::string Req7a::author()
{
	return string("cankan he");
}

class Req7b : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req7b::test()
{
	Message msg = "\n  Req #7b -sending each message to multiple streams that have been registered with the logger. .";
	plog_->write(msg);
	msg = "\n ------------------------------------------------------------------------";
	plog_->write(msg);
	std::string fileSpec = "../Test.txt";
	plog_->write("\n Adding FileStream for \"" + fileSpec + "\"");
	std::ofstream ofs(fileSpec);
	if (ofs.good())
	{
		plog_->write("\n -- opened file \"" + fileSpec + "\"");
		plog_->addStream(&ofs);
		plog_->write("\n writing to multiple streams");
		plog_->removeStream(&ofs);
		ofs.close();
		std::ifstream ifs(fileSpec);
		
		if (ifs.good())
		{
			std::ostringstream oss;
			oss << ifs.rdbuf();
			std::string fileContents = oss.str();
			fileContents = Utilities::trimNewLines(fileContents);
			plog_->write("\n contents of \"" + fileSpec + "\" are: \n");
			plog_->write(fileContents);
			plog_->write("\n  you see two identical messages, so test passed");
			return true;
		}
		return false;
	}
	else
	{
		plog_->write("-- failed to open file \"" + fileSpec + "\"");
		return false;
	}
}

DLL_DECL std::string Req7b::name()
{
	return string("requirement 7b");
}

DLL_DECL std::string Req7b::author()
{
	return string("cankan he");
}

class Req8a : public ITest {

public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedLogger(ILog* plog)
	{
		plog_ = plog;
	}
private:
	ILog* plog_ = nullptr;
};

DLL_DECL bool Req8a::test()
{
	Message msg = "\n  Req #8a -The TestHarness Core shall own the logger and provide a reference to the testdriver of a TestRequest.";
	plog_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	plog_->write(msg);
	plog_->write("\n demonstrate TestHarness Core own logger and pass point to the testdriver - see line 1231");
	Path fileSpec = "../Executor/Executor.h";
	bool t1 = Utilities::showFileLines(fileSpec, 150, 168);
	plog_->write(msg);
	plog_->write("\n demonstrate each requester get its own instance of the logger.   - see line 93");
	fileSpec = "../Project2Demo/demostrate.cpp";
	bool t2 = Utilities::showFileLines(fileSpec, 56, 70);
	return (t1 == true && t2 == true);
}

DLL_DECL std::string Req8a::name()
{
	return string("requirement 8a");
}

DLL_DECL std::string Req8a::author()
{
	return string("cankan he");
}

////////////////////////////////////////////////////////////////////////////////
//// test collection 

class TestCollection : public ITests {
	DLL_DECL std::vector<ITest*> tests();
};

DLL_DECL std::vector<ITest*> TestCollection::tests()
{
	std::vector<ITest*> tests_vec;
	tests_vec.push_back(new Req1);
	tests_vec.push_back(new Req2a);
	tests_vec.push_back(new Req2b);
	tests_vec.push_back(new Req3a);
	tests_vec.push_back(new Req3b);
	tests_vec.push_back(new Req3c);
	tests_vec.push_back(new Req4);
	tests_vec.push_back(new Req5a);
	tests_vec.push_back(new Req5b);
	tests_vec.push_back(new Req7a);
	tests_vec.push_back(new Req7b);
	tests_vec.push_back(new Req8a);
	return tests_vec;
}

//////////////////////////////////////////////////////////////////////////////
// this section is where each Test Driver DLL completely differs from other
// test drivers. Although the same name can be used in all TestDrivers, the 
// actual instance of TestCollection is different in the way it returns 
// different collection of ITest*.

DLL_DECL ITests* get_ITests()
{
	return new TestCollection;
}

