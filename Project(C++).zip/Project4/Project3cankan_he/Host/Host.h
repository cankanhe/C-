#pragma once
/////////////////////////////////////////////////////////////////////
// Host.h - Prototype for Test Harness child Tester              //
// ver 1.0                                                         //
// Cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  This package defines one class, Host:
*  - use the comm and message establish commnucation channel and
*    transfer the message from the client and child tester
*    build process pool to spanw child tester.
*  Required Files:
*  ---------------
*  Host.h, Host.cpp
*  comm.h, comm.cpp
*  Process.h, Process.cpp
*  BlockQueue.h, BlockQueue.cpp
*  ISingletonLogger.h, SingletonLogger.h
*  TestRequest.h, TestRequest.cpp
*  Properties.h, Properties.cpp
*  FileUtilities.h, FileUtilities.cpp
*
*  Maintenance History:
*  --------------------
*  ver 1.0 : 9 Nov 2018
*  - first release
*
*/
#ifndef WIN32_LEAN_AND_MEAN  // prevents duplicate includes of core parts of windows.h in winsock2.h
#define WIN32_LEAN_AND_MEAN
#endif
#include "../TestRequest/TestRequest.h"
#include "../Dll_Loader_With_Hosted_Resource/DllLoader/DllLoader.h"
#include "../Utilities/SingletonLogger/ISingletonLogger.h"
#include "../Utilities/SingletonLogger/SingletonLogger.h"
#include "../Utilities/Properties/Properties.h"
#include <vector>
#include <string>
#include "../CppCommWithFileXfer/MsgPassingComm/Comm.h"
#include "../Process/Process.h"

namespace Testing
{
	///////////////////////////////////////////////////////////////////
  // Host class
  // - Receive message from child and client
  //   Each message should be store different Blockqueue
  // - creat child process to do tester 
  // - establish comm through EndPoint
  //   using Thread to build receive endpoint
  // - send Message through comm
  //   Each message will transfer to idle child tester.
	using namespace MsgPassingCommunication;
	using Requests = std::vector<TestRequest>;
	using namespace Utilities;
	Property<Request> request;
	Property<Requests> requests;
	Property<std::string> libPath;
	Property<ILog*> pLog;
	class Host
	{
	public:
		Host(EndPoint from, EndPoint to, const std::string name);
		~Host();
		void start();
		void wait();
		void sendMsg();
		void getMsgs();
		void join();
		void spanw_childProcess();   // spanw child process
		void startclient();          // stratup  client process
	private:
		TestRequest tr1;
		EndPoint from_;
		EndPoint to_;
		Comm comm_;
		std::thread recv;         
		BlockingQueue<MsgPassingCommunication::Message> Ready;    // store the Ready Message
		BlockingQueue<MsgPassingCommunication::Message> TestRe;    // store the TestRequest Message
		Process child1;   //  init three process object using this project as startup project
		Process child2;
		Process client;
	};
}
