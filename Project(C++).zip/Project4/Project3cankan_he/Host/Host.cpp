/////////////////////////////////////////////////////////////////////
// Host.cpp   - Transfer message to child tester and create tester //
// ver 1.0                                                         //
// cankan He  , CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
#include "Host.h"
namespace Testing 
{
	//----< constructor >------------------
	Host::Host(EndPoint from, EndPoint to, const std::string name) :from_(from), to_(to), comm_(from_, name)
	{
		libPath("../SaveFile");
		pLog(Utilities::Logger<0, Utilities::Lock>::getInstance());
		pLog()->setTerminator("");
	}
	//----< destructor >------------------
	Host::~Host()
	{
		delete pLog();
	}
	//----< set comm start up >------------------
	void Host::start()
	{
		comm_.start();
		std::string savePath = comm_.setSaveFilePath("../SaveFile");
		std::cout << "\n  saving files to \"" << savePath << "\"";
	}
	//----< set Thread to receive message >------------------
	void Host::wait()
	{
		std::function<void()> tproc = [&]() { getMsgs(); };
		recv = std::thread(tproc);
	}
	//----< transfer messsage to child when it's idle >------------------
	void Host::sendMsg()
	{
		while (true)
		{
			MsgPassingCommunication::Message Tesmsg;
			Tesmsg=TestRe.deQ();                     //TestRequestQuene
			std::cout << "\n  Host deQ  message \"" << Tesmsg.command() << "\"";
			MsgPassingCommunication::Message Readymsg;
			Readymsg = Ready.deQ();                  //ReadyquestQuene will be block this thread when no child process is idle.
			std::cout << "\n  Host deQ  message \"" << Readymsg.command() << "\"";
			Tesmsg.to(Readymsg.from());               // Set Ready child Tester address as the message destination
			std::cout << "\n  Host send  message \"" << Tesmsg.command() << "\"";
			Tesmsg.de_attributes("sendingFile");      // erase sendfile attribute in message just need tell child process path  
			comm_.postMessage(Tesmsg);                //send message
		}
	}
	//----< get messsage and classify message >------------------
	void Host::getMsgs()
	{
		while (true)
		{
			MsgPassingCommunication::Message msg;
			msg = comm_.getMessage();
			std::cout << "\n  Host recvd  message \"" << msg.name() << "\"";
			if (msg.command() == "stop")       // is this a quit messge?
			{
				break;
			}
			else if (msg.command()=="testRequest")  // is this client message?
			{
				std::cout << "\n  " + comm_.name() + " received message \"" + msg.command() + "\" from " + msg.name() << "\"";
				TestRe.enQ(msg);                        // put into TestRequest Queue
				if (msg.contentLength() == 0) {
					std::cout << "\n  " + comm_.name() + " received file \"" + msg.file() + "\" from " + msg.name() << "\"";
				}
			}
			else if (msg.command() == "ready")    // is this child message?
			{
				std::cout << "\n  " + comm_.name() + " received message \"" + msg.command() + "\" from " + msg.name() << "\"";
				Ready.enQ(msg);                   // put into Ready Queue
			}
			else
			{
				std::cout << "/n Host - Invalid message  \n";
			}
		}
	}
	//----< join thread >------------------
	void Host::join()
	{
		recv.join();
	}
	//----< create child Process >------------------
	void Host::spanw_childProcess()
	{
		child1.title("child1");
		std::string appPath = "../Debug/TestHarnessCore.exe";
		child1.application(appPath);
		std::cout << "\n  starting process: \"" << appPath << "\"";
		std::string cmdLine1 = "/.. localhost 8082";        //passing the address and port number to child process
		child1.commandLine(cmdLine1);
		child1.create();
		CBP callback1 = []() { std::cout << "\n  --- child1 process exited with this message ---"; };
		child1.setCallBackProcessing(callback1);
		child1.registerCallback();

		child2.title("child2");
		child2.application(appPath);
		std::cout << "\n  starting process: \"" << appPath << "\"";
		std::string cmdLine2 = "/.. localhost 8083";       //passing the address and port number to child process
		child2.commandLine(cmdLine2);
		child2.create();
		CBP callback2 = []() { std::cout << "\n  --- child2 process exited with this message ---"; };
		child2.setCallBackProcessing(callback2);
		child2.registerCallback();
	}
	//----< start up the client >------------------
	void Host::startclient()
	{
		client.title("Tester1");
		std::string appPath = "../Debug/Client.exe";
		client.application(appPath);
		std::cout << "\n  starting process: \"" << appPath << "\"";
		client.create();
		CBP callback3 = []() { std::cout << "\n  --- client process exited with this message ---"; };
		client.setCallBackProcessing(callback3);
		client.registerCallback();
	}

}

using namespace Testing;
int main()
{
	std::cout << Utilities::sTitle("Testing Tester using Dll Loader and Logger");
	::SetConsoleTitle(L"Hoster");
	EndPoint Hoster("localhost", 8080);
	EndPoint Test("localhost", 8082);
	Host mother(Hoster, Test, "Hoster");
	mother.spanw_childProcess();
	mother.startclient();
	mother.start();
	mother.wait();
	mother.sendMsg();
	mother.join();
	
	Utilities::putline(2);
	return 0;
}