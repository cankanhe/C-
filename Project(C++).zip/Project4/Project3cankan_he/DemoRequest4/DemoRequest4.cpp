///////////////////////////////////////////////////////////////////////////
// Project3Demo1.cpp :  test class for CodeUtilities pkg                  //
// ver 1.1                                                                //
//                                                                        //
// Application : OOD F18 Project 3 Demostrate porject requirement         //
// Platform    : VS17 Community - Windows 10 Professional x64             //
// Author      : Cankan He, EECS Department, Syracuse University          //
//               che100@syr.edu                                           //
////////////////////////////////////////////////////////////////////////////
/*
*  Package description:
* ======================
*  This is a 'Mutiple test' test driver DLL package. It follows the same
*  protocol defined in ITest.h package. For DllLoader, it doesn't care
*  if the TestDriver contains one or many Test Classes as it will attempt
*  to get the collection of ITest*.
*
*  Required files:
* =================
*  ProjectDemo.cpp
*  ITest.h
*  FileUtilities.h
*  FileSystem.h
*  Maintainence History:
* =======================
*  ver 1.0 : 11 Oct 2018
*  - added Hosted ILoger interface
*  - Tests use host functionality via passed pointer to
*    IHostedResource interface
*  - first release
*/

#define IN_DLL
#define ARG_SIZE 256  // for the manufactured cmd args

#include "ITests.h"
#include "../Utilities/CodeUtilities/CodeUtilities.h"
#include "../Utilities/DateTime/DateTime.h"
#include "../Utilities/FileUtilities/FileUtilities.h"

#include <iostream>
#include <string>
#include <string.h>

using namespace Utilities;
using namespace std;
using namespace std;
using Path = std::string;
using Message = std::string;
using Line = size_t;
using File = std::string;
using Files = std::vector<File>;
using Pattern = std::string;
using Patterns = std::vector<Pattern>;


// Concrete Test class that implements ITest.
// It performs tests on ProcessCmdArgs and Convereter classes in a single test class.

class Req4a : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< requirment >------------------
DLL_DECL bool Req4a::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #4a - TestHarness Ready queue and TestRequest queue and inital process object:";
	pRes_->write(msg);
	msg = "\n========================================================================";
	pRes_->write(msg);
	pRes_->write("\n demonstrate contain Ready queue and TestRequest queue- see line 80 and 81 ");
	pRes_->write("\n demonstrate initial three process when host class create a object - see line 82,83 and 84");
	Path fileSpec = "../Host/Host.h";
	bool t1 = Utilities::showFileLines(fileSpec, 62, 85);
	pRes_->write("\n TestHarness host just receive message and put it into correctly queue and send TestRequest to the idle child Tester");
	pRes_->write("\n the detail already showed in the Requirment3, And when host start up it create the child process, it also showed in the Requirment3.");
	return t1;
}
//----< name >------------------
DLL_DECL std::string Req4a::name()
{
	return string("Demo Request4a");
}
//----< author >------------------
DLL_DECL std::string Req4a::author()
{
	return string("cankan he");
}
//----< Requirment >------------------
class Req4b : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< Requirment>------------------
DLL_DECL bool Req4b::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #4b - Child process Operate";
	pRes_->write(msg);
	msg = "\n========================================================================";
	pRes_->write(msg);
	pRes_->write("\n demonstrate child Tester rececive message operates");
	Path fileSpec = "../TestHarnessCore/Tester.cpp";
	bool t1 = Utilities::showFileLines(fileSpec, 102, 121);
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	pRes_->write("\n demonstrate child Tester send message operates");
	fileSpec = "../TestHarnessCore/Tester.cpp";
	bool t2 = Utilities::showFileLines(fileSpec, 122, 159);
	return (t1 == true && t2 == true);
}
//----< name >------------------
DLL_DECL std::string Req4b::name()
{
	return string("Demo Request2b");
}
//----< author >------------------
DLL_DECL std::string Req4b::author()
{
	return string("cankan he");
}
//////////////////////////////////////////////////////////////////////////////
// test collection 

class TestCollection : public ITests {
	DLL_DECL std::vector<ITest*> tests();
};
//----< push back ITests vector >------------------
DLL_DECL std::vector<ITest*> TestCollection::tests()
{
	std::vector<ITest*> tests_vec;
	tests_vec.push_back(new Req4a);
	tests_vec.push_back(new Req4b);

	return tests_vec;
}

//////////////////////////////////////////////////////////////////////////////
// this section is where each Test Driver DLL completely differs from other
// test drivers. Although the same name can be used in all TestDrivers, the 
// actual instance of TestCollection is different in the way it returns 
// different collection of ITest*.

DLL_DECL ITests* get_ITests()
{
	return new TestCollection;
}

