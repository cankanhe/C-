///////////////////////////////////////////////////////////////////////////
// Project3Demo1.cpp :  test class for CodeUtilities pkg                  //
// ver 1.1                                                                //
//                                                                        //
// Application : OOD F18 Project 3 Demostrate porject requirement         //
// Platform    : VS17 Community - Windows 10 Professional x64             //
// Author      : Cankan He, EECS Department, Syracuse University          //
//               che100@syr.edu                                           //
////////////////////////////////////////////////////////////////////////////
/*
*  Package description:
* ======================
*  This is a 'Mutiple test' test driver DLL package. It follows the same
*  protocol defined in ITest.h package. For DllLoader, it doesn't care
*  if the TestDriver contains one or many Test Classes as it will attempt
*  to get the collection of ITest*.
*
*  Required files:
* =================
*  ProjectDemo.cpp
*  ITest.h
*  FileUtilities.h
*  FileSystem.h
*  Maintainence History:
* =======================
*  ver 1.0 : 11 Oct 2018
*  - added Hosted ILoger interface
*  - Tests use host functionality via passed pointer to
*    IHostedResource interface
*  - first release
*/

#define IN_DLL
#define ARG_SIZE 256  // for the manufactured cmd args

#include "ITests.h"
#include "../Utilities/CodeUtilities/CodeUtilities.h"
#include "../Utilities/DateTime/DateTime.h"
#include "../Utilities/FileUtilities/FileUtilities.h"

#include <iostream>
#include <string>
#include <string.h>
using namespace Utilities;
using namespace std;
using namespace std;
using Path = std::string;
using Message = std::string;
using Line = size_t;
using File = std::string;
using Files = std::vector<File>;
using Pattern = std::string;
using Patterns = std::vector<Pattern>;


// Concrete Test class that implements ITest.
// It performs tests on ProcessCmdArgs and Convereter classes in a single test class.

class Req3a : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< requirment >------------------
DLL_DECL bool Req3a::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #3a Create a 2 of Child Processes which execute all the tests";
	pRes_->write(msg);
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	pRes_->write("\n demonstrate by viewing code");
	Path fileSpec = "../Host/Host.cpp";
	return Utilities::showFileLines(fileSpec, 87, 110);
}
//----< name >------------------
DLL_DECL std::string Req3a::name()
{
	return string("Demo Request3a");
}
//----< author >------------------
DLL_DECL std::string Req3a::author()
{
	return string("cankan he");
}
//----< Requirment >------------------
class Req3b : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< Requirment>------------------
DLL_DECL bool Req3b::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #3b - Post client TestRequest messages to the TestRequest Queue and Child Ready messages to the Ready Queue with a receive thread.";
	pRes_->write(msg);
	msg = "\n========================================================================";
	pRes_->write(msg);
	pRes_->write("\n demonstrate Post client TestRequest messages to the TestRequest Queue and Child Ready messages to the Ready Queue");
	msg = "\n------------------------------------------------------------------------";
	Path fileSpec = "../Host/Host.cpp";
	pRes_->write(msg);
	bool t1 = Utilities::showFileLines(fileSpec, 51, 81);
	pRes_->write("\n demonstrate put above function into a receive thread");
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	pRes_->write("\n demonstrate by viewing code - see line 40");
	fileSpec = "../Host/Host.cpp";
	bool t2 = Utilities::showFileLines(fileSpec, 28, 33);
	return (t1 == true && t2 == true);
}
//----< name >------------------
DLL_DECL std::string Req3b::name()
{
	return string("Demo Request3b");
}
//----< author >------------------
DLL_DECL std::string Req3b::author()
{
	return string("cankan he");
}
//----< Requirment >------------------
class Req3c : public ITest {
public:
	DLL_DECL bool test();
	DLL_DECL std::string name();
	DLL_DECL std::string author();

	// get access to Hosted Resource
	DLL_DECL void acceptHostedResource(ILog* pRes)
	{
		pRes_ = pRes;
	}

private:
	ILog* pRes_ = nullptr;
};
//----< Requirment>------------------
DLL_DECL bool Req3c::test()
{
	if (pRes_ == nullptr)
	{
		std::cout << "\n  no logger available";
		return false;
	}
	Message msg = "\n  Req #3c -Mother(Host) process deQue TestRequest and Ready message Process.";
	pRes_->write(msg);
	msg = "\n========================================================================";
	pRes_->write(msg);
	pRes_->write("\n demonstrate Host  send Message process");
	msg = "\n------------------------------------------------------------------------";
	pRes_->write(msg);
	Path fileSpec = "../Host/Host.cpp";
	bool t1 = Utilities::showFileLines(fileSpec, 34, 50);
	bool t2 = true;
	return (t1 == true && t2 == true);
}
//----< name >------------------
DLL_DECL std::string Req3c::name()
{
	return string("Demo Request3c");
}
//----< author >------------------
DLL_DECL std::string Req3c::author()
{
	return string("cankan he");
}
//////////////////////////////////////////////////////////////////////////////
// test collection 

class TestCollection : public ITests {
	DLL_DECL std::vector<ITest*> tests();
};
//----< push back ITests vector >------------------
DLL_DECL std::vector<ITest*> TestCollection::tests()
{
	std::vector<ITest*> tests_vec;
	tests_vec.push_back(new Req3a);
	tests_vec.push_back(new Req3b);
	tests_vec.push_back(new Req3c);

	return tests_vec;
}

//////////////////////////////////////////////////////////////////////////////
// this section is where each Test Driver DLL completely differs from other
// test drivers. Although the same name can be used in all TestDrivers, the 
// actual instance of TestCollection is different in the way it returns 
// different collection of ITest*.

DLL_DECL ITests* get_ITests()
{
	return new TestCollection;
}

