﻿/////////////////////////////////////////////////////////////////////
// MainWindow.xaml.cs - Prototype for OOD Project #4               //
// ver 1.1                                                         //
// Jim Fawcett, CSE687 - Object Oriented Design, Fall 2018         //
/////////////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package defines one class MainWindow that provides tabs:
 * - Find Libs: Navigate through local directory to find files for testing
 *   - Shows local directories and files
 *   - Can navigate by double clicking directories
 *   - Can select files by selecting.  That displays selections in a popup window.
 * - Request Tests: left for students
 * - Show Results:  left for students
 * 
 * Required Files:
 * ---------------
 * MainWindow.xaml, MainWindow.xaml.cs
 * SelectionWindow.xaml, SelectionWindow.xaml.cs
 * 
 * Maintenance History:
 * --------------------
 * ver 1.1 : 16 Nov 2018
 * - fixed bug in Files_SelectionChanged by checking e.AddedItems.Count
 *   and returning if 0.
 * ver 1.0 : 15 Nov 2018
 * - first release
 * 
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using MsgPassingCommunication;
using System.IO;

namespace PrototypeGui_OOD_Pr4
{
    ///////////////////////////////////////////////////////////////////
    // MainWindow class
    // - Provides navigation and selection to find libraries to test.
    // - Creates a popup window to handle selections.

    public partial class MainWindow : Window
    {
        public string path { get; set; }
        List<string> selectedFiles { get; set; } = new List<string>();
        List<string> Filename { get; set; } = new List<string>();
        List<string> Filepath { get; set; } = new List<string>();
        public SelectionWindow swin { get; set; } = null;
        bool unselecting = false;
        private string FileName = "";

        private Translater translater;
        private CsEndPoint endPoint_;
        private CsEndPoint serverEndPoint;
        private Thread rcvThrd = null;
        private Dictionary<string, Action<CsMessage>> dispatcher_
          = new Dictionary<string, Action<CsMessage>>();
        public MainWindow()
        {
            InitializeComponent();
        }
        //----< open window showing contents of project directory >------

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            endPoint_ = new CsEndPoint();
            endPoint_.machineAddress = "localhost";
            endPoint_.port = 8090;
            serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            translater = new Translater();
            translater.listen(endPoint_);

            processMessages();
            loadDispatcher();
            path = Directory.GetCurrentDirectory();
            path = getAncestorPath(2, path);
            LoadNavTab(path);

        }
        //----< find parent paths >--------------------------------------

        string getAncestorPath(int n, string path)
        {
            for (int i = 0; i < n; ++i)
                path = Directory.GetParent(path).FullName;
            return path;
        }
        //----< file Find Libs tab with subdirectories and files >-------

        void LoadNavTab(string path)
        {
            Dirs.Items.Clear();
            CurrPath.Text = path;
            string[] dirs = Directory.GetDirectories(path);
            Dirs.Items.Add("..");
            foreach (string dir in dirs)
            {
                DirectoryInfo di = new DirectoryInfo(dir);
                string name = System.IO.Path.GetDirectoryName(dir);
                Dirs.Items.Add(di.Name);
            }
            Files.Items.Clear();
            string[] files = Directory.GetFiles(path);
            foreach (string file in files)
            {
                string name = System.IO.Path.GetFileName(file);
                Files.Items.Add(name);
            }
        }
        //----< handle selections in files listbox >---------------------

        private void Files_SelectionChanged(
          object sender, SelectionChangedEventArgs e
        )
        {
            if (unselecting)
            {
                unselecting = false;
                return;
            }
            if (swin == null)
            {
                swin = new SelectionWindow();
                swin.setMainWindow(this);
            }
            swin.Show();

            if (e.AddedItems.Count == 0)
                return;
            string selStr = e.AddedItems[0].ToString();
            FileName = e.AddedItems[0].ToString();
            selStr = System.IO.Path.Combine(path, selStr);
            if (!selectedFiles.Contains(selStr))
            {
                selectedFiles.Add(selStr);
                Filename.Add(FileName);
                Filepath.Add(path.ToString());
                swin.Add(selStr);
            }
        }
        //----< unselect files called by unloading SelectionWindow >-----

        public void unselectFiles()
        {
            unselecting = true;  // needed to avoid using selection logic
                                 //selectedFiles.Clear();
            Files.UnselectAll();
        }
        //----< move into double-clicked directory, display contents >---

        private void Dirs_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string selectedDir = Dirs.SelectedItem.ToString();
            if (selectedDir == "..")
                path = getAncestorPath(1, path);
            else
                path = System.IO.Path.Combine(path, selectedDir);
            LoadNavTab(path);

        }
        //----< shut down the SelectionWindow if open >------------------

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            swin.Close();
        }
        public void processMessages()
        {
            ThreadStart thrdProc = () =>
            {
                while (true)
                {
                    CsMessage msg = translater.getMessage();
                    string msgId = msg.value("command");

                    if (dispatcher_.ContainsKey(msgId))
                        dispatcher_[msgId].Invoke(msg);
                }
            };
            rcvThrd = new Thread(thrdProc);
            rcvThrd.IsBackground = true;
            rcvThrd.Start();
        }
        //----< load all dispatcher processing >---------------------------

        private void loadDispatcher()
        {
            DispatcherLoadGetResult();
        }
        //----< load getResult processing into dispatcher dictionary >-------

        private void DispatcherLoadGetResult()
        {
            Action<CsMessage> getresult = (CsMessage rcvMsg) =>
            {
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("result"))
                    {
                        Action<string> doDir = (string dir) =>
                        {
                            addres(dir);
                        };
                        Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
                    }
                }
            };
            addClientProc("testResult", getresult);

        }
        //----< send testrequest to server and show the request  >------------------
        public void SendMessage()
        {
            for (int i = 0; i < selectedFiles.Count; i++)
            {
                CsMessage msg = new CsMessage();
                msg.add("to", CsEndPoint.toString(serverEndPoint));
                msg.add("from", CsEndPoint.toString(endPoint_));
                msg.add("command", "testRequest");
                msg.add("path", Filepath[i]);
                msg.add("sendingFile", Filename[i]);
                string time = DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt");
                string tr1 = "DemostrationProject4,cankan he,";
                tr1 += time;
                tr1 += ",";
                tr1 += Filename[i];
                msg.add("testRequest", tr1);
                addRequestList(tr1);
                translater.setPath(msg);
                translater.postMessage(msg);
            }
        }
        //----<  add the test request to the gui >------------------
        private void addRequestList(string testRequest)
        {
            RequestList.Items.Add(testRequest);
        }
        //----< add client processing for message with key >---------------

        private void addClientProc(string key, Action<CsMessage> clientProc)
        {
            dispatcher_[key] = clientProc;
        }
        //----< function dispatched by child thread to main thread >-------

        private void addres(string dir)
        {
            ResultList.Items.Add(dir);
        }
    }
}
